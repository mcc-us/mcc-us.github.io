---
title: "Learning Logistic Regression"  
tags: Data_Science Logit
---



<div class="pdf-container">
    <iframe src="/assets/docs/04-logit.pdf" title="Logistic Regression" height="400" width="712" allowfullscreen="false">
    </iframe>
</div>
