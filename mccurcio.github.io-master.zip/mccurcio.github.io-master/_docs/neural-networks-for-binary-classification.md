---
title: "Learning Neural Networks"   
tags: Data_Science
---

<div class="pdf-container">
    <iframe src="/assets/docs/05-neural-network.pdf" title="Neural Netowrks" height="400" width="712" allowfullscreen="false">
    </iframe>
</div>
