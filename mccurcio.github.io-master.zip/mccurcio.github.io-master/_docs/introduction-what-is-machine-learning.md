---
title: "What Is Machine Learning"   
tags: Data_Science
---

<div class="pdf-container">
    <iframe src="/assets/docs/what-is-ml.pdf"  title="What is ML" height="400" width="712" allowfullscreen="false">
    </iframe>
</div>
