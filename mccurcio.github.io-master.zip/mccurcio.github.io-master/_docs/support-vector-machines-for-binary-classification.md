---
title: "Learning Support Vector Machines"  
tags: SVM Data_Science
---

<div class="pdf-container">
    <iframe src="/assets/docs/06-svm.pdf" height="400" width="712" allowfullscreen="false" title="Learning Support Vector Machines">
    </iframe>
</div>
