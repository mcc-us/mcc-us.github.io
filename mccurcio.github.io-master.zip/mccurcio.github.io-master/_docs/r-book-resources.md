---
title:  "Free Online R Book Resources"
date:   2022-04-09 18:30:00
tags: Books Resources Free R
---

:star: - Represents Favorites 

Row | A | B
-:|--------------|-----------
 1 | :star: [What They Forgot to Teach You About R](https://rstats.wtf/) | [Tidyverse Skills For DS in R](https://leanpub.com/tidyverseskillsdatascience)
 2 |  [Tabular DA w/ R & Tidyverse: Environmental Health](https://static-bcrf.biochem.wisc.edu/courses/Tabular-data-analysis-with-R-&-Tidyverse/book/) | [GGplot2](https://ggplot2-book.org/index.html)
 3 |  [Modern Dive, Statistical Inference via DS](https://moderndive.com/) | [Regression & Other Stories](https://avehtari.github.io/ROS-Examples/)
 4 |  [Bookdown, Blogdown, Rmarkdown](https://bookdown.org) | [RStudio For Education](https://rstudio4edu.github.io/rstudio4edu-book/)
 5 |  [R 4 DS](https://r4ds.had.co.nz/) | [Intro. To DS: Data Analysis & Prediction Algorithms w/ R](https://rafalab.github.io/dsbook/)
 6 |  [R Packages](https://r-pkgs.org/) | [R Cookbook](https://rc2e.com/)
 7 |  [Engineering Production-Grade Shiny Apps](https://engineering-shiny.org/) | [Mastering Shiny](https://mastering-shiny.org/)
 8 |  [Beyond Multiple Lin. Regression: Gen. Lin. Models & Multilevel Models](https://bookdown.org/roback/bookdown-BeyondMLR/) | [Advanced R](https://adv-r.hadley.nz/)
 9 |  [Tidy Modeling w/ R](https://tmwr.org) | [Text Mining w/ R](https://www.tidytextmining.com/)
10 |  [DS In Education Using R](https://datascienceineducation.com/) | [Geocomputation w/ R](https://geocompr.robinlovelace.net/)
11 | [Data Science Live Book](https://livebook.datascienceheroes.com/) | [An Introduction to R](https://cran.r-project.org/doc/manuals/R-intro.pdf)
12 | [R for Health Data Science](https://argoshare.is.ed.ac.uk/healthyr_book/) | [Bayes Rules! An Introduction to Applied Bayesian Modeling](https://www.bayesrulesbook.com/)
13 | [Fundamentals of Data Visualization](https://clauswilke.com/dataviz/) | [A Short Course on Nonparametric Curve Estimation](https://bookdown.org/egarpor/NP-EAFIT/)
14 | [Introduction to Data Exploration and Analysis with R](https://bookdown.org/mikemahoney218/IDEAR/) | [Data Science with R: A Resource Compendium](https://bookdown.org/martin_monkman/DataScienceResources_book/)
15 | [Forecasting: Principles and Practice, 3rd ed.](https://otexts.com/fpp3/) | [Data Science at the Command Line](https://datascienceatthecommandline.com/)
16 | [Introduction to Econometrics with R](https://www.econometrics-with-r.org/index.html) | [Modern Data Science with R](https://mdsr-book.github.io/mdsr2e/)
17 | [Engineering Production-Grade Shiny Apps](https://engineering-shiny.org/index.html) | [Happy Git with R](https://happygitwithr.com/)

- [Swirl](https://swirlstats.com/) is an excellent beginner tool for learning R  
