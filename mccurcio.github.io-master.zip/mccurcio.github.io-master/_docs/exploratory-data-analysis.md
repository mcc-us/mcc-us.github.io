---
title: "Beginning Exploratory Data Analysis"  
tags: Data_Science EDA
---

<div class="pdf-container">
    <iframe src="/assets/docs/02-eda.pdf" title="Exploratory Data Analysis" height="400" width="712" allowfullscreen="false">
    </iframe>
</div>
