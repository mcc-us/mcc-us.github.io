---
title: "Learning Principle Component Analysis"  
tags: Data_Science PCA
---

<div class="pdf-container">
    <iframe src="/assets/docs/03-pca.pdf" height="400" width="712" allowfullscreen="false" title="Principal Component Analysis">
    </iframe>
</div>
