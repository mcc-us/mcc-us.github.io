---
title: "Big data & rice?"
tags: Data_Science
---

![](/assets/img/rice-data.png)