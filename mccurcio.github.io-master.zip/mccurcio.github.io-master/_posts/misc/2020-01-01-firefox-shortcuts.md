---
title: "Firefox shortcuts"
tags: Firefox
---


| Command          | Shortcut |
| :----------------| :--------|
| Refresh Page     | [CTRL] + R |
| New Private Page | [CTRL] + [SHIFT] + P |
| Bookmark A Page  | [CTRL] + D |
| Manage Bookmarks | [CTRL] + [SHIFT] + O |
| Zoom In / Out    | [CTRL] + (**+**) / [CTRL] + (**-**) |
| Show All History | [CTRL] + [SHIFT] + H |

