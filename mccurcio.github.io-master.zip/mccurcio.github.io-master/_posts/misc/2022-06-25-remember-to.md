---
title: "Remember to:"
---

Try to remember to do 'some' of these things daily/weekly or even monthly. lol

1. Find a good hobby
2. Reduce my Netflix intake
3. Go deeper into a subject
4. Finish my website projects page
5. *Eat well, Sleep well, Walk everyday*
6. Find exercises for indoors (sit-ups, push-ups?)
7. Learn chess
8. Meditate; **Every day**
9. Read about Buddhism
10. Be genorous to **everybody**
11. Learn a little Spanish (Weekly)
12. Find a mentor
13. Be a mentor
14. Make good choices everyday
15. Eat more vegetables and fruit
16. Cut back on bread & cereal
17. Learn Django
18. Get involved with a Community group, volunteer
19. Push yourself
20. Take more chances
21. Plan *more and better*
22. Write out a goal (Every day)
23. Learn to give and take constructive criticism
24. Don't believe in Magic
25. Don't take things for granted, find out how things work.
26. Learn to live with fear
27. Listen **more** & talk **less**
28. Blog more
29. Learn to debug on an IDE, Spyder?
30. Walk EVERY DAY (second time, must be important, lol)
31. Don't be afraid to ask for help
32. Learn to Mind Map better
33. Be kinder to family
34. Take breaks (often)
35. Track my progress
36. Keep a diary
37. Take inventory of strengths
38. Take inventory of areas for improvement
39. BE curious
40. Pace myself
41. Learn to Pseudo-code better
42. Write science articles
43. Read more books
44. Define my career goals
45. Prioritize tasks
46. Don't overlook details
47. Be nicer to myself
48. Apply for jobs above your pay grade
49. Build up a portfolio (blog posts, videos, articles)
50. Be kind to yourself
