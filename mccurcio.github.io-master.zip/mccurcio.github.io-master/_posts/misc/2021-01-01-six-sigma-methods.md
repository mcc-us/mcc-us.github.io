---
title: "Six-Sigma methods"
tags: Productivity
---

![](/assets/img/six-sigma.png)
