---
title: "Matt's Common Linux Installs"
date: 2019-01-31
tags: Linux
---


Matt's Linux Mint Install Script


```
sudo apt install bleachbit tmux audacity bluefish bzip2 catfish cheese curl dropbox build-essential gimp htop gparted sqlitebrowser tree vlc xed keepass2 p7zip p7zip-full diodon soundconverter freeplane calibre pinta gnome-calculator transmission-gtk gimp-gap aisleriot
```


