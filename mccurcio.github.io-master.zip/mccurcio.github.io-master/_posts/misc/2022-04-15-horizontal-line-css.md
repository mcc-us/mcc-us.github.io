---
title: "Horizontal lines in CSS/MD"
tags: CSS
---

Change horizontal line in css `<hr>`

```
hr {
    margin-top: 0.5rem;
    margin-bottom: 0.5rem;
    border: 0;
    border-top: 1px solid rgba(0, 0, 0, .1) /* Change: 2-3 px AND/OR alpha=.2 or .3
}
```
