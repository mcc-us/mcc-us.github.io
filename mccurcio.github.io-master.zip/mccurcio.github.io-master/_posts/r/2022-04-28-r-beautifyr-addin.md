---
title: "R - beautifyR; Favorite RStudio addon"
tags: R Addin
---


Add this Awesome **addin** to RStudio during installation!

beautifyR has   
- Beautify tables **Awesome**   

See: [https://github.com/mwip/beautifyR](https://github.com/mwip/beautifyR`)

To install it from Github use:

```{r}
devtools::install_github('mwip/beautifyR')
```

See also: [https://www.r-bloggers.com/2020/01/rstudio-addins-or-how-to-make-your-coding-life-easier/](https://www.r-bloggers.com/2020/01/rstudio-addins-or-how-to-make-your-coding-life-easier/)
