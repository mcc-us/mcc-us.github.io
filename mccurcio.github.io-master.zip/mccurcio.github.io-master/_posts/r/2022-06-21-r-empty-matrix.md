---
title: R - Produce Empty Matrix
tags: R Matrix
---


- Create empty matrix with 10 rows and 3 columns WITH NA's

`empty_matrix <- matrix(, nrow=10, ncol=3)`

- Create empty matrix with 10 rows and 3 columns WITH Zeros

`empty_matrix <- matrix(0, nrow=10, ncol=3)`
