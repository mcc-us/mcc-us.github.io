---
title: "R - Insert Comments for .r & .rmd"
tags: R Comments
---


- **[Super] + [Shift] + [C] on Linux**

- **[Ctrl] + [Shift] + [C] on Windows**

This shortcut can be used both for:

- To comment your R code: It adds **#** at the beginning of each line
- For R Markdown: It will add **`<!-- and -->`** around text


To uncomment:  apply **[Super] + [Shift] + [C]** Again!
