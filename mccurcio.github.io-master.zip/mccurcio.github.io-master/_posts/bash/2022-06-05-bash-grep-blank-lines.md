---
title: "Grep - Remove blank lines"
tags: Bash Grep
---


Remove blank lines from a file using grep and save output to new file:

```bash
grep . old.filename.txt > new.filename.txt
```


