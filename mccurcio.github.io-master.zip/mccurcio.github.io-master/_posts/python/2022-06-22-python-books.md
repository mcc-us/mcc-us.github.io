---
title: "Python Books"
tags: Python Books
---

:star: - Represents Favorites 

Row | A | B
-:|--------------|-----------
 1 | :star: [Think Python by Allen Downey](https://greenteapress.com/wp/) | [Syncfusion Free ebooks](https://www.syncfusion.com/succinctly-free-ebooks)
 2 |  | 
