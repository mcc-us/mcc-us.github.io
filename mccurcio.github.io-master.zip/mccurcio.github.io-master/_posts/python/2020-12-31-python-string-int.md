---
title: "Python - Converting string to int"
tags: Python String
---


Converting string to int

```
print('3252')
try:
    print(int('x'))
except:
    print('Conversion Failed')
else:
    print('Conversion scuccessful')
print('Done')   

```


