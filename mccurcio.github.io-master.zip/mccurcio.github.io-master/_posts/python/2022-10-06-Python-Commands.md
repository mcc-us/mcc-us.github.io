---
title: "Python Commands Cheat Sheet" 
date: 2022-10-06 
categories: python 
tags: python dictionary list set reserved string
---

<div class="pdf-container"> 
    <iframe src="/assets/docs/python_commands.pdf" height="400" width="712" allowfullscreen="" frameborder="10"> 
    </iframe> 
</div>
