---
layout: page
title: Matt's Coding Site
permalink: /
---

## Matt's Coding Site

The goals for this site:

1. Share my learning journey via my
   - [Articles](docs)
   - [Presentations](docs/mcc-presentations)
   - [Posts by title](archive)

*It may seem like I don't learn something everyday, but that's not true. I don't always remember to write it down.* 😉

## Have a Question or Comment?

- <a href="mailto:matt.curcio.ri@gmail.com?subject=A question from the web">Send An Email</a>, or leave feedback via GitHub.
