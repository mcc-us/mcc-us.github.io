---
title: About Matt
permalink: /about/
---

# Welcome

I am a Scientist, Sales-Person, Patient Educator, and a Data Scientist.

Among my best qualities are Dilgence, Inquistiveness and Resourcefulness.  

My tools include Presentation skills, Statistics, Data Science, R, and Python to impart ideas.

*Matt*

## Have a Question?

- <a href="mailto:matt.curcio.ri@gmail.com?subject=Greetings from a new friend">Send An Email</a>, or leave feedback below.
